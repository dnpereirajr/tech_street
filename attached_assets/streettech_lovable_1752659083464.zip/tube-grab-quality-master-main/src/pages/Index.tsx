import YouTubeDownloader from '@/components/YouTubeDownloader';

const Index = () => {
  return <YouTubeDownloader />;
};

export default Index;
